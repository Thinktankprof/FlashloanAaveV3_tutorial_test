# Flash Loan Complete Tutorial

Install packages - `npm i @aave/core-v3 `

* Exchange Address on Sepolia - 0xE52b2C89049184A8C145231E1E84529771B915F7
